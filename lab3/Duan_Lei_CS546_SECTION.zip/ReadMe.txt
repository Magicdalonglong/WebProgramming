the below four js files are what lab3 requested 
MongoDBcollection.js
MongoDBconnection.js
todo.js
app.js
.

app2.js is another test app file that i used.

Terminal Saved Output for app.js is the result of app.js which requested in lab3

Terminal Saved Output for app2.js is the result of app2.js