Last login: Sun Oct  2 21:20:49 on ttys000
You have new mail.
host-155-246-143-24:~ Leigh$ cd Desktop/546/lab3/
host-155-246-143-24:lab3 Leigh$ npm start

> lab3@1.0.0 start /Users/Leigh/Desktop/546/lab3
> node app.js

here is app

going to create a task
{ _id: 'b882b910-8907-11e6-8243-a162c6bbae74',
  title: 'Ponder Dinosaurs',
  description: 'Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?',
  completed: false,
  completedAt: null }

going to create another task
{ _id: 'b8f3f170-8907-11e6-8243-a162c6bbae74',
  title: 'Play Pokemon with Twitch TV',
  description: 'Should we revive Helix?',
  completed: false,
  completedAt: null }

going to getAllTasks
[ { _id: 'b882b910-8907-11e6-8243-a162c6bbae74',
    title: 'Ponder Dinosaurs',
    description: 'Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?',
    completed: false,
    completedAt: null },
  { _id: 'b8f3f170-8907-11e6-8243-a162c6bbae74',
    title: 'Play Pokemon with Twitch TV',
    description: 'Should we revive Helix?',
    completed: false,
    completedAt: null } ]

going to removeTask
Remove successfully

going to getAllTasks
[ { _id: 'b8f3f170-8907-11e6-8243-a162c6bbae74',
    title: 'Play Pokemon with Twitch TV',
    description: 'Should we revive Helix?',
    completed: false,
    completedAt: null } ]

going to completeTask
completeTask successfully

going to getAllTasks
[ { _id: 'b8f3f170-8907-11e6-8243-a162c6bbae74',
    title: 'Play Pokemon with Twitch TV',
    description: 'Should we revive Helix?',
    completed: true,
    completedAt: '9:21:37 PM' } ]

=====Demo completed, thank you!=====

